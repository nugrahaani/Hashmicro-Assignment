<?php
require('function/connect.php');
session_start();

if (isset($_SESSION['username']) && isset($_COOKIE["playername"])) {
  header("Location: dashboard.php?username=" . $_SESSION['username']);
}

if (isset($_POST['login'])) {
  $user = mysqli_real_escape_string($conn, $_POST['username']);
  $pass = mysqli_real_escape_string($conn, $_POST['password']);

  $query = "SELECT * FROM admin WHERE username = '$user' AND password = '$pass'";

  $result = mysqli_query($conn, $query) or die(mysql_error());
  $count = mysqli_num_rows($result);
  if ($count == 1) {
    $row = mysqli_fetch_array($result);
    $_SESSION["id_user"] = $row["id_user"];
    $_SESSION["username"] = $row["username"];

    //set up cookie
    setcookie("playerid", $row['id_user'], time() + 7776000);
    setcookie("playername", $row['username'], time() + 7776000);

    header("Location: dashboard.php?username=" . $_SESSION['username']);
  } else {
    echo "<script>alert('username or password is wrong'); window.location='login.php';</script>";
  }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Kuku Cake</title>
  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!--Import materialize.css-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  <link href="https://fonts.googleapis.com/css?family=Delius+Unicase:700|Dosis:700|Poppins&display=swap" rel="stylesheet">
  <link rel="shorcut icon" href="img/2.png">
  <style>
    .one {
      font-family: 'Dosis', sans-serif;
    }

    .two {
      font-family: 'Delius Unicase', cursive;
    }

    .three {
      font-family: 'Poppins', sans-serif;
    }

    .warna {
      color: #f07550;
    }

    .warna-dua {
      color: #df6f5a;
    }

    /* css mobile view only */
    @media only screen and (max-width: 600px) {
      .bg-img {
        width: 100% !important;
        margin-top: -40px;
      }

      .tops {
        margin-top: -70px;
      }
    }

    /* css desktop view only */
    @media only screen and (min-width: 800px) {
      .tops {
        margin-top: -120px;
      }

      .bg-img {
        width: 800px;
        margin-top: -105px;
      }
    }
  </style>
</head>

<body class="grey lighten-4">

  <div style="background-color: #df6f5a; height: auto;">
    <br>

    <div class="container">
      <h3 class="white-text center three">Login to Admin</h3>
      <p class="center white-text">you can easily add product</p>
    </div>
    <br>
    <br>
  </div>
  <br>
  <br>
  <form class="col s12 container" method="post" autocomplete="off">
    <div class="row">
      <div class="input-field col s12">
        <input placeholder="admin username" id="first_name" type="text" name="username" class="validate" required>
        <label for="first_name">Username</label>
      </div>
      <div class="input-field col s12">
        <input placeholder="admin password" id="last_name" type="password" name="password" class="validate" required>
        <label for="last_name">Password</label>
      </div>
    </div>
    <center>
      <button type="submit" name="login" class="btn-large white-text z-depth-0" style="background-color:#df6f5a; border-radius: 30px; width: 150px;">login</button>
    </center>
  </form>


  <br>

  <!--JavaScript at end of body for optimized loading-->
  <script type="text/javascript" src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <script type="text/javascript" src="js/init.js"></script>
</body>

</html>