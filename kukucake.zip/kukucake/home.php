<div id="carousel-id" class="carousel slide" data-ride="carousel">
	<ol class="carousel-indicators">
		<li data-target="#carousel-id" data-slide-to="0" class=""></li>
		<li data-target="#carousel-id" data-slide-to="1" class=""></li>
		<li data-target="#carousel-id" data-slide-to="2" class="active"></li>
	</ol>
	<div class="carousel-inner">
		<div class="item">
			<img alt="First slide" src="http://localhost/2017/cake-olshop/logged/slider/slider1.jpg">
			<div class="container">
				<div class="carousel-caption">
					<!--<h1>Example headline.</h1>
					<p>Note: If you're viewing this page via a <code>file://</code> URL, the "next" and "previous" Glyphicon buttons on the left and right might not load/display properly due to web browser security rules.</p> -->
					
				</div>
			</div>
		</div>
		<div class="item">
			<img  alt="Second slide" src="http://localhost/2017/cake-olshop/logged/slider/slider2.jpg">
			<div class="container">
				<div class="carousel-caption">
					<!--<h1>Another example headline.</h1>
					<p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
					-->
                    
				</div>
			</div>
		</div>
		<div class="item active">
			<img  alt="Second slide" src="http://localhost/2017/cake-olshop/logged/slider/slider3.jpg">
			<div class="container">
				<div class="carousel-caption">
					<!--<h1>Another example headline.</h1>
					<p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
					-->
                    
				</div>
			</div>
		</div>
	</div>
	<a class="left carousel-control" href="#carousel-id" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
	<a class="right carousel-control" href="#carousel-id" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
</div>

<?php require_once('produk.php'); ?>
