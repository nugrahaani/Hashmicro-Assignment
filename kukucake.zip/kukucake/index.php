<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Kuku Cake</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  <link href="https://fonts.googleapis.com/css?family=Delius+Unicase:700|Dosis:700|Poppins&display=swap" rel="stylesheet">
  <link rel="shorcut icon" href="img/2.png">
  <style>
    .one {
      font-family: 'Dosis', sans-serif;
    }

    .two {
      font-family: 'Delius Unicase', cursive;
    }

    .three {
      font-family: 'Poppins', sans-serif;
    }

    .warna {
      color: #f07550;
    }

    .warna-dua {
      color: #df6f5a;
    }
    @media only screen and (max-width: 600px) {
      .bg-img {
        width: 100% !important;
        margin-top: -40px;
      }

      .tops {
        margin-top: -70px;
      }
    }
    @media only screen and (min-width: 800px) {
      .tops {
        margin-top: -120px;
      }

      .bg-img {
        width: 800px;
        margin-top: -105px;
      }
    }
  </style>
</head>

<body>

  <center>
    <img src="img/2.png" class="bg-img" style="" alt=""><br><br>
    <h4 class="two warna-dua tops">KukuCake</h4>
    <p class="one" style="margin-top: -10px;">a piece of happiness</p>

    <p class="three center" style="font-size: 20px;">For our cakes,<br>
      we always use only the natural ingredients.<br>
      Our production is
      100% handmade.</p>

    <a href="#cakes" class="btn-large z-depth-0" style="margin-top: -10px; border-radius: 30px; background-color: #df6f5a; width: 200px;">find your cakes</a>
  </center>
  <br>
  <div class="container">
    <h2 class="one warna">About Us</h2>
    <div class="row">
      <div class="col s12 m6">
        <p align=justify >Kuku Cake berdiri tahun 2019, dimulai dengan tugas mata kuliah Struktur Data sehingga menjadi sebuah toko kue.
</p>
<p align=justify >Kuku Cake adalah perusahaan lokal dan bukan dari luar Indonesia, menghadirkan cake yang tak kalah lezat dan inovatif dibanding produk dari luar negeri. Cita rasanya InsyaAllah disesuaikan dengan keinginan selera masyarakat Indonesia. Bahkan unsur kesehatan mendapat perhatian terutama dalam memilih bahan-bahan yang berkualitas.</p>
      </div>

      <div class="col s12 m6">
        <img src="img/1.jpg" style="width: 100%;" alt="">
      </div>
    </div>
  </div>


  <div class="row container three section scrollspy" id="cakes">
    <div class="col s12 m3">
      <div class="card white center" style="border-radius: 10px;">
        <div class="card-content">
          <span class="card-title">All<br> Cakes</span>
          <a href="all.php" class="btn-large z-depth-0" style="border-radius: 30px; background-color: #df6f5a;">explore</a>
        </div>
      </div>
    </div>
    <div class="col s12 m3">
      <div class="card white center" style="border-radius: 10px;">
        <div class="card-content">
          <span class="card-title">Birthday<br> Cakes</span>
          <a href="birthday.php" class="btn-large z-depth-0" style="border-radius: 30px; background-color: #df6f5a;">explore</a>
        </div>
      </div>
    </div>
    <div class="col s12 m3">
      <div class="card white center" style="border-radius: 10px;">
        <div class="card-content">
          <span class="card-title">Wedding<br> Cakes</span>
          <a href="wedding.php" class="btn-large z-depth-0" style="border-radius: 30px; background-color: #df6f5a;">explore</a>
        </div>
      </div>
    </div>
    <div class="col s12 m3">
      <div class="card white center" style="border-radius: 10px;">
        <div class="card-content">
          <span class="card-title">Dessert<br> Cakes</span>
          <a href="dessert.php" class="btn-large z-depth-0" style="border-radius: 30px; background-color: #df6f5a;">explore</a>
        </div>
      </div>
    </div>
  </div>

  <div style="background-color: #df6f5a; height: auto; margin-top: -120px;">
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
  </div>
  <script type="text/javascript" src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <script type="text/javascript" src="js/init.js"></script>
</body>

</html>