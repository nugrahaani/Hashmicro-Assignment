<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Kuku Cake</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  <link href="https://fonts.googleapis.com/css?family=Delius+Unicase:700|Dosis:700|Poppins&display=swap" rel="stylesheet">
  <link rel="shorcut icon" href="img/2.png">
  <style>
    .one {
      font-family: 'Dosis', sans-serif;
    }

    .two {
      font-family: 'Delius Unicase', cursive;
    }

    .three {
      font-family: 'Poppins', sans-serif;
    }

    .warna {
      color: #f07550;
    }

    .warna-dua {
      color: #df6f5a;
    }
    @media only screen and (max-width: 600px) {
      .bg-img {
        width: 100% !important;
        margin-top: -40px;
      }

      .tops {
        margin-top: -70px;
      }
    }
    @media only screen and (min-width: 800px) {
      .tops {
        margin-top: -120px;
      }

      .bg-img {
        width: 800px;
        margin-top: -105px;
      }
    }
  </style>
</head>

<body class="grey lighten-4">
  <nav style="background-color: #df6f5a;">
    <div class="nav-wrapper container">
      <div class="col s12 center">
        <a href="index.php" class="breadcrumb">Home</a>
        <a href="all.php" class="breadcrumb">Dessert Cakes</a>
      </div>
    </div>
  </nav>

  <div style="background-color: #df6f5a; height: auto;">
    <br>

    <div class="container">
      <h3 class="white-text center three">Dessert Cakes</h3>
      <p class="center white-text">For our cakes,
        we always use only the natural ingredients.
        Our production is 100% handmade.</p>

      <p class="white-text one center" style="font-size: 20px;">interested?</p>
    </div>
    <br>
    <br>
  </div>
  <center>
    <a href="all.php" class="btn-large white warna-dua" style="margin-top: -30px; border-radius: 30px;">mail to kukucake@gmail.com</a>
  </center>

  <br>
  <div class="row">
    <div class="col s12">
      <ul class="tabs transparent">
        <li class="tab col s4"><a class="active" href="#test1">A-Z</a></li>
        <li class="tab col s4"><a href="#test2">Lower Price</a></li>
        <li class="tab col s4"><a href="#test3">Higher Price</a></li>
      </ul>
    </div>
    <div id="test1">
      <div class="row">
        <?php
        include("function/connect.php");
        $q = mysqli_query($conn, "SELECT * FROM product WHERE category='dessert' ORDER BY name ASC");
        while ($row = mysqli_fetch_assoc($q)) {
          $name = $row['name'];
          $about = $row['about'];
          $price = $row['price'];
          $image = $row['image'];

          $file = "img/product/" . $image;

          if (file_exists($file) && $image) {
            $ava = "img/product/" . $image;
          } else {
            $ava = 'img/party.png';
          }
          ?>
          <div class="col s6 m3">
            <div class="card z-depth-0" style="border-radius: 10px;">
              <div class="card-image waves-effect waves-block waves-light" style="border-radius: 10px 10px 0px 0px;">
                <img class="activator" src="<?php echo $ava; ?>">
              </div>
              <div class="card-content">
                <span class="card-title activator warna-dua"><?php echo $name; ?><i class="material-icons right">more_vert</i></span>
                <div class="chip">
                  RP.<?php echo number_format($price, 0, ".", "."); ?>
                </div>
              </div>
              <div class="card-reveal">
                <span class="card-title warna-dua"><?php echo $name; ?><i class="material-icons right">close</i></span>
                <p><?php echo nl2br($about); ?></p>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>
    <div id="test2" class="col s12">
      <div class="row">
        <?php
        include("function/connect.php");
        $q = mysqli_query($conn, "SELECT * FROM product WHERE category='dessert' ORDER BY CAST(price AS int) ASC");
        while ($row = mysqli_fetch_assoc($q)) {
          $name = $row['name'];
          $about = $row['about'];
          $price = $row['price'];
          $image = $row['image'];

          $file = "img/product/" . $image;

          if (file_exists($file) && $image) {
            $ava = "img/product/" . $image;
          } else {
            $ava = 'img/party.png';
          }
          ?>
          <div class="col s6 m3">
            <div class="card z-depth-0" style="border-radius: 10px;">
              <div class="card-image waves-effect waves-block waves-light" style="border-radius: 10px 10px 0px 0px;">
                <img class="activator" src="<?php echo $ava; ?>">
              </div>
              <div class="card-content">
                <span class="card-title activator warna-dua"><?php echo $name; ?><i class="material-icons right">more_vert</i></span>
                <div class="chip">
                  RP.<?php echo number_format($price, 0, ".", "."); ?>
                </div>
              </div>
              <div class="card-reveal">
                <span class="card-title warna-dua"><?php echo $name; ?><i class="material-icons right">close</i></span>
                <p><?php echo nl2br($about); ?></p>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>
    <div id="test3" class="col s12">
      <div class="row">
        <?php
        include("function/connect.php");
        $q = mysqli_query($conn, "SELECT * FROM product WHERE category='dessert' ORDER BY CAST(price AS int) DESC");
        while ($row = mysqli_fetch_assoc($q)) {
          $name = $row['name'];
          $about = $row['about'];
          $price = $row['price'];
          $image = $row['image'];

          $file = "img/product/" . $image;

          if (file_exists($file) && $image) {
            $ava = "img/product/" . $image;
          } else {
            $ava = 'img/party.png';
          }
          ?>
          <div class="col s6 m3">
            <div class="card z-depth-0" style="border-radius: 10px;">
              <div class="card-image waves-effect waves-block waves-light" style="border-radius: 10px 10px 0px 0px;">
                <img class="activator" src="<?php echo $ava; ?>">
              </div>
              <div class="card-content">
                <span class="card-title activator warna-dua"><?php echo $name; ?><i class="material-icons right">more_vert</i></span>
                <div class="chip">
                  RP.<?php echo number_format($price, 0, ".", "."); ?>
                </div>
              </div>
              <div class="card-reveal">
                <span class="card-title warna-dua"><?php echo $name; ?><i class="material-icons right">close</i></span>
                <p><?php echo nl2br($about); ?></p>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <script type="text/javascript" src="js/init.js"></script>
</body>

</html>