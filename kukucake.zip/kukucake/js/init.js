(function ($) {
  $(function () {

    $('.sidenav').sidenav();
    $('.parallax').parallax();
    $('.scrollspy').scrollSpy();
    $('.tabs').tabs();
    $('select').formSelect();

  }); // end of document ready
})(jQuery); // end of jQuery name space