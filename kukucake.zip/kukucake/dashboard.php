<?php
include('function/connect.php');
include('function/periksa.php');


if (isset($_POST['submit'])) {
  $name = $_POST['name'];
  $about = $_POST['about'];
  $price = $_POST['price'];
  $cat = $_POST['category'];
  $cvr = $_FILES['image']['name'];
  $tmps = $_FILES['image']['tmp_name'];

  $cek = mysqli_num_rows(mysqli_query($conn, "SELECT name FROM product WHERE name='$name'"));

  if ($cek > 0) {
    echo "<script>history.back(alert('Failed! Product Name Already Exist.'))</script>";
  } else {

    $temp = explode(".", $_FILES["image"]["name"]);
    $new = round(microtime(true)) . '.' . end($temp);

    $path = "img/product";
    $paths = "img/product/" . $new;



    if (!is_dir($path)) {
      mkdir("img/product", 0777);
    }

    if (move_uploaded_file($tmps, $paths)) {
      $chg = mysqli_query($conn, "INSERT INTO product(name, about, image, price, category) VALUES('$name', '$about', '$new', '$price', '$cat')");

      if ($chg) {
        echo '<script>alert("Success!"); window.location="dashboard.php?username=' . $_SESSION['username'] . '"</script>';
      } else {
        echo '<script>alert("Failed!"); window.location="dashboard.php?username=' . $_SESSION['username'] . '"</script>';
      }
    } else {
      echo '<script>alert("Failed to upload image! Please rename or choose another"); window.location="dashboard.php?username=' . $_SESSION['username'] . '"</script>';
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Kuku Cake</title>
  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!--Import materialize.css-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  <link href="https://fonts.googleapis.com/css?family=Delius+Unicase:700|Dosis:700|Poppins&display=swap" rel="stylesheet">
  <link rel="shorcut icon" href="img/2.png">
  <style>
    .one {
      font-family: 'Dosis', sans-serif;
    }

    .two {
      font-family: 'Delius Unicase', cursive;
    }

    .three {
      font-family: 'Poppins', sans-serif;
    }

    .warna {
      color: #f07550;
    }

    .warna-dua {
      color: #df6f5a;
    }

    /* css mobile view only */
    @media only screen and (max-width: 600px) {
      .bg-img {
        width: 100% !important;
        margin-top: -40px;
      }

      .tops {
        margin-top: -70px;
      }
    }
    @media only screen and (min-width: 800px) {
      .tops {
        margin-top: -120px;
      }

      .bg-img {
        width: 800px;
        margin-top: -105px;
      }
    }
  </style>
</head>

<body class="grey lighten-4">
  <nav style="background-color: #df6f5a;">
    <div class="nav-wrapper container">
      <div class="col s6">
        <a href="login.php" class="breadcrumb">Login</a>
        <a href="dashboard.php?username=<?php echo $_SESSION['username']; ?>" class="breadcrumb">Dashboard</a>
      </div>
      <div class="right">
        <a href="logout.php">
          <div class="chip white">
            logout
          </div>
        </a>
      </div>
    </div>
  </nav>

  <div style="background-color: #df6f5a; height: auto;">
    <br>

    <div class="container">
      <h3 class="white-text center three">Welcome Admin</h3>
    </div>
    <br>
    <br>

    <div class="row">
      <div class="col s12">
        <ul class="tabs transparent">
          <li class="tab col s6"><a class="white-text active" href="#test1">My Product</a></li>
          <li class="tab col s6"><a class="white-text" href="#test2">Add Product</a></li>
        </ul>
      </div>
    </div>

  </div>
  <br>
  <br>

  <div class="row">
    <div id="test1" class="col s12">
      <div class="row">
        <?php
        include("function/connect.php");
        $q = mysqli_query($conn, "SELECT * FROM product ORDER BY id_product DESC");
        while ($row = mysqli_fetch_assoc($q)) {
          $name = $row['name'];
          $about = $row['about'];
          $price = $row['price'];
          $image = $row['image'];

          $file = "img/product/" . $image;

          if (file_exists($file) && $image) {
            $ava = "img/product/" . $image;
          } else {
            $ava = 'img/party.png';
          }
          ?>
          <div class="col s6 m3">
            <div class="card z-depth-0" style="border-radius: 10px;">
              <div class="card-image waves-effect waves-block waves-light" style="border-radius: 10px 10px 0px 0px;">
                <img class="activator" src="<?php echo $ava; ?>">
              </div>
              <div class="card-content">
                <span class="card-title activator warna-dua"><?php echo $name; ?><i class="material-icons right">more_vert</i></span>
                <div class="chip">
                  RP.<?php echo number_format($price, 0, ".", "."); ?>
                </div>
              </div>
              <div class="card-reveal">
                <span class="card-title warna-dua"><?php echo $name; ?><i class="material-icons right">close</i></span>
                <p><?php echo nl2br($about); ?></p>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>

    <div id="test2" class="col s12">
      <div class="container">
        <form class="col s12" method="post" autocomplete="off" enctype="multipart/form-data">
          <div class="row">
            <div class="input-field col s12">
              <input placeholder="product name" id="first_name" name="name" type="text" class="validate" required>
              <label for="first_name">Name</label>
            </div>
            <div class="input-field col s12">
              <textarea placeholder="product description" name="about" id="textarea1" class="materialize-textarea"></textarea>
              <label for="textarea1">Description</label>
            </div>

            <br>
            <div class="file-field input-field col s12">
              <div class="btn">
                <span>File</span>
                <input type="file" name="image" accept="image/*">
              </div>
              <div class="file-path-wrapper">
                <input class="file-path validate" type="text" name="image">
              </div>
            </div>
            <div class="input-field col s12">
              <input placeholder="product price" id="first_name" name="price" type="number" class="validate" required>
              <label for="first_name">Price</label>
            </div>

            <div class="input-field col s12">
              <select name="category">
                <option value="" disabled selected>Choose your option</option>
                <option value="dessert">Dessert Cakes</option>
                <option value="wedding">Wedding Cakes</option>
                <option value="birthday">Birthday Cakes</option>
              </select>
              <label>Category</label>
            </div>

          </div>
          <center>
            <button type="submit" name="submit" class="btn-large white-text z-depth-0" style="background-color:#df6f5a; border-radius: 30px; width: 150px;">Add</button>
          </center>
        </form>
      </div>
    </div>
  </div>
  <br>
  <script type="text/javascript" src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <script type="text/javascript" src="js/init.js"></script>
</body>

</html>